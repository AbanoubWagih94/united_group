<link rel="icon" type="image/png" href="{{ asset('front/e-tower/img/favicon/favicon.png') }}">
      <!-- Bootstrap core CSS -->
<link href="{{ asset('front/e-tower/vendor/bootstrap/css/bootstrap.min.css') }}" rel="stylesheet">
<!-- Material Design Icons -->
<link href="{{ asset('front/e-tower/vendor/icons/css/materialdesignicons.min.css') }}" media="all" rel="stylesheet" type="text/css" />
<!-- Select2 CSS -->
<link href="{{ asset('front/e-tower/vendor/select2/css/select2-bootstrap.css') }}" />
<link href="{{ asset('front/e-tower/vendor/select2/css/select2.min.css') }}" rel="stylesheet" />
<!-- Custom styles for this template -->
<link href="{{ asset('front/e-tower/css/style.css') }}" rel="stylesheet">

<link href="{{ asset('front/e-tower/css/droidarabickufi.css') }}" rel="stylesheet">

<link href="{{ asset('admin/fonts/fontawesome.css') }}" rel="stylesheet" />