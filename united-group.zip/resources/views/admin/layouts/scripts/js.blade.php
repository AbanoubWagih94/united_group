<!-- Core JS -->
<!-- build:js assets/vendor/js/core.js -->
<script src="{{ asset('admin/libs/jquery/jquery.js') }}"></script>
<script src="{{ asset('admin/libs/popper/popper.js') }}"></script>

<script src="{{ asset('admin/js/bootstrap.js') }}"></script>
<script src="{{ asset('admin/libs/perfect-scrollbar/perfect-scrollbar.js') }}"></script>

<script src="{{ asset('admin/libs/hammer/hammer.js') }}"></script>

<script src="{{ asset('admin/libs/i18n/i18n.js') }}"></script>
<script src="{{ asset('admin/libs/typeahead-js/typeahead.js') }}"></script>

<script src="{{ asset('admin/js/menu.js') }}"></script>
<!-- endbuild -->

<!-- Main JS -->

<script src="{{ asset('admin/libs/quill/quill.js') }}"></script>
<script src="{{ asset('admin/libs/quill/katex.js') }}"></script>

<script src="{{ asset('admin/js/main.js') }}"></script>

<script src="{{ asset('admin/js/forms-editors.js') }}"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.0/sweetalert.min.js"></script>