<?php


return [
    'comment'=> 'Leave a Comment',
    'submit'=> 'Submit Comment',
    'recent'=>'Recent Posts'

];