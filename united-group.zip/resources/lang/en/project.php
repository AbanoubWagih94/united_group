<?php

return [
    'description'=> 'Description',
    'video_title'=> 'Property Video',
    'location'=> 'Location',
    'add_review'=> 'Add Review',
    'review'=> 'Review',
    'submit'=> 'Submit Review',
    'uploads' => 'Upload Photos',
    'review_message'=> 'Your rating for this listing',
];
