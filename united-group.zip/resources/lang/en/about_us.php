<?php


return [
    'about_title'=> 'About Our Company',
    'choose_us_text'=> 'We provide full service at every step.',
    'team' => 'Our Team',
    'partners' => 'Our Partners',
    'partners_text' => 'The Companies That Represent Us.',
];
