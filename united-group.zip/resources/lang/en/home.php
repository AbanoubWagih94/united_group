<?php

return [
    'home'=> 'Home',
    'about-us'=> 'About Us',
    'why'=> 'Why',
    'choose_us' => 'Choose Us',
    'exhibitions' => 'Exhibitions',
    'events'=> 'Events',
    'read_more'=> 'Read More',
    'latest'=> 'Latest',
    'news'=> 'News',
    'contact_us'=> 'Contact us',
    'projects'=> 'Projects',
    'next'=> 'Next',
    'prev'=> 'Previous',
    'view_details'=> 'View Details',
    'careers'=> 'Careers',

];
