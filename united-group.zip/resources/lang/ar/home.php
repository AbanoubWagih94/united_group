<?php


return [
    'home'=> 'الرئيسية',
    'about-us'=> 'من نحن',
    'why'=> 'لماذا',
    'choose_us' => 'تختارنا',
    'exhibitions'=>'المعارض',
    'events' => 'الاحداث',
    'read_more'=> 'المزيد',
    'latest'=> 'أخر',
    'news'=> 'الاخبار',
    'contact_us'=> 'تواصل معنا',
    'projects'=> 'المشاريع',
    'next'=> 'التالى',
    'prev'=> 'السابق',
    'view_details'=> 'عرض التفاصيل',
    'careers'=> 'الوظائف',


];