<?php

return [
    'description'=> 'التفاصيل',
    'video_title'=> 'فيديو الملكية',
    'location'=> 'العنوان',
    'add_review'=> 'إضافة تقييم',
    'review'=> 'التقييم',
    'submit'=> 'إرسال التقييم',
    'uploads' => 'أضافة صورة',
    'review_message'=> 'تقييمك لهذه القائمة',
];
