<?php


return [
    'about_title'=> 'عن شركتنا',
    'choose_us_text'=> '.نحن نقدم خدمة كاملة في كل خطوة',
    'team' => 'فريقنا',
    'partners' => 'شركاؤنا',
    'partners_text' => 'الشركات التي تمثلنا.',

];
