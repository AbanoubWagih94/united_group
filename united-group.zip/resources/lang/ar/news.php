<?php


return [
    'comment'=> 'اترك تعليقا',
    'submit'=> 'إرسل تعليق',
    'recent'=>'أحدث الاخبار'

];