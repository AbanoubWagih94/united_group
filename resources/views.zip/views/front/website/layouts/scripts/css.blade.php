
<link rel="shortcut icon" type="image/x-icon" href="favicon.ico">
<link rel="stylesheet" href="{{ asset('front/website/css/jquery-ui.css') }}">

<link rel="stylesheet" href="{{ asset('front/website/css/fontawesome-all.min.css') }}">
<link rel="stylesheet" href="{{ asset('front/website/css/fontawesome-5-all.min.css') }}">
<link rel="stylesheet" href="{{ asset('front/website/css/font-awesome.min.css') }}">
<!-- Slider Revolution CSS Files -->
<link rel="stylesheet" href="{{ asset('front/website/revolution/css/settings.css') }}">
<link rel="stylesheet" href="{{ asset('front/website/revolution/css/layers.css') }}">
<link rel="stylesheet" href="{{ asset('front/website/revolution/css/navigation.css') }}">
<!-- ARCHIVES CSS -->
<link rel="stylesheet" href="{{ asset('front/website/css/slider-home18.css') }}">
<link rel="stylesheet" href="{{ asset('front/website/css/search.css') }}">
<link rel="stylesheet" href="{{ asset('front/website/css/animate.css') }}">
<link rel="stylesheet" href="{{ asset('front/website/css/aos.css') }}">
<link rel="stylesheet" href="{{ asset('front/website/css/aos2.css') }}">
<link rel="stylesheet" href="{{ asset('front/website/css/swiper.min.css') }}">
<link rel="stylesheet" href="{{ asset('front/website/css/magnific-popup.css') }}">
<link rel="stylesheet" href="{{ asset('front/website/css/lightcase.css') }}">
<link rel="stylesheet" href="{{ asset('front/website/css/owl-carousel.css') }}">
<link rel="stylesheet" href="{{ asset('front/website/css/owl.carousel.min.css') }}">
<link rel="stylesheet" href="{{ asset('front/website/css/bootstrap.min.css') }}">
<link rel="stylesheet" href="{{ asset('front/website/css/menu.css') }}">
<link rel="stylesheet" href="{{ asset('front/website/css/slick.css') }}">
<link rel="stylesheet" href="{{ asset('front/website/css/styles.css') }}">
<link rel="stylesheet" href="{{ asset('front/website/css/maps.css') }}">
<link rel="stylesheet" id="color" href="{{ asset('front/website/css/colors/light-black.css') }}">