<!-- Copyright -->
<section class="pt-4 pb-4">
  <div class="container">
     <div class="row align-items-center text-center text-md-left">
        <div class="col-md-12">
           <p class="mt-0 mb-0" style="text-align: center">

              ©2022. All rights reserved -
              <a href="https://www.loadserv.com.eg" target="_blank" title=" Web Development by LoadServ Integrated Business Solutions " rel="author">
                 Development BY :
              </a>
              LoadServ.Com.Eg</p>
        </div>
     </div>
  </div>
  {!! $setting->footer_code !!}
</section>
<!-- End Copyright -->