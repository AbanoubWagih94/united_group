<!-- Bootstrap core JavaScript -->
<script src="{{ asset('front/e-tower/vendor/jquery/jquery.min.js') }}"></script>
<script src="{{ asset('front/e-tower/vendor/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
<!-- Contact form JavaScript -->
<!-- Do not edit these files! In order to set the email address and subject line for the contact form go to the bin/contact_me.php file. -->
<script src="{{ asset('front/e-tower/js/jqBootstrapValidation.js') }}"></script>
<script src="{{ asset('front/e-tower/js/contact_me.js') }}"></script>
<!-- select2 Js -->
<script src="{{ asset('front/e-tower/vendor/select2/js/select2.min.js') }}"></script>
<!-- Custom -->
<script src="{{ asset('front/e-tower/js/custom.js') }}"></script>

<script src="https://unpkg.com/sweetalert2@7.18.0/dist/sweetalert2.all.js"></script>