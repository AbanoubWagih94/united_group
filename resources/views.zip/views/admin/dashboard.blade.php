@extends('admin.layouts.master')

@section('title')
    Dashboard
@endsection

@push('custom-css-scripts')
  
@endpush

@section('content')

@endsection

@push('custom-js-scripts')

@endpush