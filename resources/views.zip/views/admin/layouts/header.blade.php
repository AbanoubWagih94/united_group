<aside id="layout-menu" class="layout-menu-horizontal menu-horizontal menu bg-menu-theme flex-grow-0">
    <div class="container-xxl d-flex h-100">
      <ul class="menu-inner">
        <!-- Dashboards -->
        <li class="menu-item {{ (request()->is('admin_panel/home') || request()->is('admin_panel/about_us') 
        || request()->is('admin_panel/projects') || request()->is('admin_panel/events')
        || request()->is('admin_panel/exhibitions') || request()->is('admin_panel/news')
        || request()->is('admin_panel/careers') || request()->is('admin_panel/contact_us'))
        ? 'active' : '' }}">
          <a href="#" class="menu-link menu-toggle">
            <i class="menu-icon tf-icons bx bx-collection"></i>
            <div data-i18n="UDG">UDG</div>
          </a>
        <ul class="menu-sub">
          <li class="menu-item {{ request()->is('admin_panel/home') ? 'active' : '' }}">
            <a href="{{ route('udg.home') }}" class="menu-link">
              <i class="menu-icon tf-icons bx bx-cog"></i>
              <div data-i18n="Home">Home</div>
            </a>
          </li>
          <li class="menu-item {{ request()->is('admin_panel/about_us') ? 'active' : '' }}">
            <a href="{{ route('udg.about_us') }}" class="menu-link">
              <i class="menu-icon tf-icons bx bx-cog"></i>
              <div data-i18n="About Us">About Us</div>
            </a>
          </li>
          <li class="menu-item {{ request()->is('admin_panel/projects') ? 'active' : '' }}">
            <a href="{{ route('udg.projects') }}" class="menu-link">
              <i class="menu-icon tf-icons bx bx-cog"></i>
              <div data-i18n="Projects">Projects</div>
            </a>
          </li>
          <li class="menu-item {{ request()->is('admin_panel/events') ? 'active' : '' }}">
            <a href="{{ route('udg.events') }}" class="menu-link">
              <i class="menu-icon tf-icons bx bx-cog"></i>
              <div data-i18n="Events">Events</div>
            </a>
          </li>
          <li class="menu-item {{ request()->is('admin_panel/exhibitions') ? 'active' : '' }}">
            <a href="{{ route('udg.exhibitions') }}" class="menu-link">
              <i class="menu-icon tf-icons bx bx-cog"></i>
              <div data-i18n="Exhibitions">Exhibitions</div>
            </a>
          </li>
          <li class="menu-item {{ request()->is('admin_panel/news') ? 'active' : '' }}">
            <a href="{{ route('udg.news') }}" class="menu-link">
              <i class="menu-icon tf-icons bx bx-cog"></i>
              <div data-i18n="News">News</div>
            </a>
          </li>
          <li class="menu-item {{ request()->is('admin_panel/careers') ? 'active' : '' }}">
            <a href="{{ route('udg.careers') }}" class="menu-link">
              <i class="menu-icon tf-icons bx bx-cog"></i>
              <div data-i18n="Careers">Careers</div>
            </a>
          </li>
          <li class="menu-item {{ request()->is('admin_panel/contact_us') ? 'active' : '' }}">
            <a href="{{ route('udg.contact_us') }}" class="menu-link">
              <i class="menu-icon tf-icons bx bx-cog"></i>
              <div data-i18n="Contact Us">Contact Us</div>
            </a>
          </li>
        </ul>
        <!-- Pages -->
        <li class="menu-item {{ (request()->is('admin_panel/e_tower/sliders') || request()->is('admin_panel/e_tower/page_details') || request()->is('admin_panel/e_tower/facilities') || request()->is('admin_panel/e_tower/messages')) ? 'active' : '' }}">
          <a href="#" class="menu-link menu-toggle">
            <i class="menu-icon tf-icons bx bx-collection"></i>
            <div data-i18n="E-TOWER">E-TOWER</div>
          </a>
          <ul class="menu-sub">
            <li class="menu-item {{ request()->is('admin_panel/e_tower/sliders') ? 'active' : '' }}">
              <a href="{{ route('e-tower.sliders') }}" class="menu-link">
                <i class="menu-icon tf-icons bx bx-slideshow"></i>
                <div data-i18n="Sliders">Sliders</div>
              </a>
            </li>
            <li class="menu-item {{ request()->is('admin_panel/e_tower/page_details') ? 'active' : '' }}">
              <a href="{{ route('e-tower.page_details') }}" class="menu-link">
                <i class="menu-icon tf-icons bx bx-detail"></i>
                <div data-i18n="Page Details">Page Details</div>
              </a>
            </li>
            <li class="menu-item {{ request()->is('admin_panel/e_tower/facilities') ? 'active' : '' }}">
              <a href="{{ route('e-tower.facilities') }}" class="menu-link">
                <i class="menu-icon tf-icons bx bx-shield-alt-2"></i>
                <div data-i18n="Facilities">Facilities</div>
              </a>
            </li>
            <li class="menu-item {{ request()->is('admin_panel/e_tower/messages') ? 'active' : '' }}">
              <a href="{{ route('e-tower.messages') }}" class="menu-link">
                <i class="menu-icon tf-icons bx bxs-message-dots"></i>
                <div data-i18n="Messages">Messages</div>
              </a>
            </li>
            <li class="menu-item {{ request()->is('admin_panel/e_tower/settings') ? 'active' : '' }}">
              <a href="{{ route('e-tower.settings') }}" class="menu-link">
                <i class="menu-icon tf-icons bx bx-cog"></i>
                <div data-i18n="Settings">Settings</div>
              </a>
            </li>
          </ul>
        </li>

      </ul>
    </div>
  </aside>